message ='Ingresa el precio del producto:'

print(message)
number=input()

print('El precio del producto es ${number}.'.format(number=number))
