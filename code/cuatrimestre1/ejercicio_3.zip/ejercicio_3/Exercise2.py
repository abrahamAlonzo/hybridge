print('Ingrese su nombre')
firstName=input()
print('Mi nombre es {firstName}'.format(firstName=firstName))