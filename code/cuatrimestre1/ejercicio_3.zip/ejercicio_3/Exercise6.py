message ='Ingresa tu edad'

print(message)
age=input()

print('Tienes {age} años.'.format(age=age))